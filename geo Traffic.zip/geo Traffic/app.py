from flask import Flask, render_template, request, jsonify
import pandas as pd
import pickle
import numpy as np

app = Flask(__name__)

# Load the trained model and label encoders
with open('finalized_model.pkl', 'rb') as model_file:  
    model = pickle.load(model_file)

with open('label_encoders.pkl', 'rb') as encoder_file:  
    label_encoders = pickle.load(encoder_file)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/home')
def home():
    return render_template("home.html")

@app.route('/da')
def dat():
    data = pd.read_csv("combined_data.csv")
    return render_template("data.html",tables=[data.to_html()],titles=[''])

@app.route('/predict', methods=['POST'])
def predict():
    # Extract input data from the form
    manual_input_data = {
        'Type Road': request.form['Type Road'],
        'Road Features': request.form['Road Features'],
        'Traffic Control': request.form['Traffic Control'],
        'Latitude': float(request.form['Latitude']),
        'Longitude': float(request.form['Longitude'])
    }
    
    # Convert input data into a DataFrame
    input_df = pd.DataFrame([manual_input_data])

    # Apply label encoding to categorical features
    for column in ['Type Road', 'Road Features', 'Traffic Control']:
        input_df[column] = label_encoders[column].transform(input_df[column])

    # Concatenate encoded categorical data and numerical data
    new_data = input_df[['Type Road', 'Road Features', 'Traffic Control', 'Latitude', 'Longitude']]

    # Make prediction
    prediction = model.predict(new_data)

    # Interpret the prediction
    if prediction[0] == 3:
        result = "Fatal"
    elif prediction[0] == 2:
        result = "Grevious Injury" 
    elif prediction[0] == 1:
        result = "Minor Injury"

    # Return the result
    return render_template('result.html', prediction=result)

if __name__ == '__main__':
    app.run(debug=True)

